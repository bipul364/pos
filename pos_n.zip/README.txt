How to Install
-------------------------
1. Go to http://phppointofsale.com/manual.pdf to download the latest manual.