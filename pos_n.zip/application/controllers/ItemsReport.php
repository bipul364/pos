<?php
require_once ("secure_area.php");
class ItemsReport extends Secure_area 
{
	function __construct()
	{
		parent::__construct('ItemsReport');
	}
	
	function index()
	{	
 
	$this->load->model('ItemReportsModel');
// $model = new SaleReportsModel;
// $model= new itemreportsmodel ();
		
		$customers = array();
		foreach($this->ItemReportsModel->get_all_item()->result() as $item)
		{
			$items[$item->item_id] = $item->name;
		}
		$data['specific_input_data'] = $items;
// 		$this->load->view("reports/specific_input",$data);
		
		$this->load->view("itemReports", $data);
	}
	
	function invreport()
	{
// 		$model = new SaleReportsModel;e
			 
// 		print_r($_REQUEST);
		$datefrom=$_REQUEST['datefrom'];
		$dateto=$_REQUEST['dateto'];
		$specific_input_data=$_REQUEST['specific_input_data'];
		$data['item']=$_REQUEST['specific_input_data'];
		
	 	$this->load->model('ItemReportsModel');
	 $data['salesdata']=	$this->ItemReportsModel->report_item_details($datefrom,$dateto,$specific_input_data)->result();
		
// 	 print"<pre>";
//  	 print_r($data);
//      print"</pre>";
	 
	 
		$this->load->view("DetailsInvenReports", $data);
	}
	
	
	 
	
	function backup()
	{
		$this->load->dbutil();
		$prefs = array(
			'format'      => 'txt',             // gzip, zip, txt
			'add_drop'    => FALSE,              // Whether to add DROP TABLE statements to backup file
			'add_insert'  => TRUE,              // Whether to add INSERT data to backup file
			'newline'     => "\n"               // Newline character used in backup file
    	);
		$backup =&$this->dbutil->backup($prefs);
		$backup = 'SET FOREIGN_KEY_CHECKS = 0;'."\n".$backup."\n".'SET FOREIGN_KEY_CHECKS = 1;';
		force_download('php_point_of_sale.sql', $backup);
	}
	
	function optimize()
	{
		$this->load->dbutil();
		$this->dbutil->optimize_database();
		echo json_encode(array('success'=>true,'message'=>lang('config_database_optimize_successfully')));
	}
}
?>