<?php
require_once ("secure_area.php");
class DetailsReports extends Secure_area 
{
	function __construct()
	{
		parent::__construct('DetailsReports');
	}
	
	function index()
	{	
 
	$this->load->model('salereportsfroallmodel');
// $model = new SaleReportsModel;
		
// 		$customers = array();
// 		foreach($this->salereportsfroallmodel->get_all()->result() as $customer)
// 		{
// 			$customers[$customer->person_id] = $customer->first_name .' '.$customer->last_name;
// 		}
// 		$data['specific_input_data'] = $customers;
// 		$this->load->view("reports/specific_input",$data);
		
		$this->load->view("SalesReportsall", $data);
	}
	
	function specific_sale()
	{
// 		$model = new SaleReportsModel;
			 
// 		print_r($_REQUEST);
		$datefrom=$_REQUEST['datefrom'];
		$dateto=$_REQUEST['dateto'];
	 	$this->load->model('salereportsfroallmodel');
	 	
// 	 	->result()
	 $data['salesdata'] =	$this->salereportsfroallmodel->report_sales_details($datefrom,$dateto)->result();
		
	 $data['datefrom']=$datefrom;
	 $data['dateto']=$dateto;
// 	 print"<pre>";
//  	 print_r($data['salesdata']);
//      print"</pre>";
	$this->load->view("DetailsSalesReportsforall", $data);
	}
	
	
	 
	
	function backup()
	{
		$this->load->dbutil();
		$prefs = array(
			'format'      => 'txt',             // gzip, zip, txt
			'add_drop'    => FALSE,              // Whether to add DROP TABLE statements to backup file
			'add_insert'  => TRUE,              // Whether to add INSERT data to backup file
			'newline'     => "\n"               // Newline character used in backup file
    	);
		$backup =&$this->dbutil->backup($prefs);
		$backup = 'SET FOREIGN_KEY_CHECKS = 0;'."\n".$backup."\n".'SET FOREIGN_KEY_CHECKS = 1;';
		force_download('php_point_of_sale.sql', $backup);
	}
	
	function optimize()
	{
		$this->load->dbutil();
		$this->dbutil->optimize_database();
		echo json_encode(array('success'=>true,'message'=>lang('config_database_optimize_successfully')));
	}
}
?>