<?php
$lang['customers_new']='Nouveau Client';
$lang['customers_customer']='Client';
$lang['customers_update']='Actualizer le Client';
$lang['customers_confirm_delete']='est vous sure de vouloir supprimer le client sélectionner?';
$lang['customers_none_selected']='vous navez pas sélection de client pour supression';
$lang['customers_error_adding_updating'] = 'Erreur en ajoutant/éffacent le client';
$lang['customers_successful_adding']='vous avez ajouter le client avec succès';
$lang['customers_successful_updating']='vous avez Actualiser le client avec succès';
$lang['customers_successful_deleted']='vous avez suprimer le client avec succès';
$lang['customers_one_or_multiple']='client(s)';
$lang['customers_cannot_be_deleted']='Impossible de suprimer le client sélectionner. un ou plusieurs clients a une vente en coure.';
$lang['customers_basic_information']='Informacion du Clients';
$lang['customers_account_number']='Compte #';
$lang['customers_taxable']='Taxable';
$lang['customers_most_imported_some_failed'] = 'La plupart des clients importés. Mais certains ne sont pas, voici la liste de leur code';
$lang['customers_import_successfull'] = 'Importation des clients réussie';
$lang['customers_mass_import_from_excel'] = 'Données d\'importation de masse de la feuille excel';
$lang['customers_download_excel_import_template'] = 'Télécharger le Modèle Excel d\'importation(CSV)';
$lang['customers_import'] = 'Importation';
$lang['customers_full_path_to_excel_required'] = 'Chemin complet du fichier Excel nécessaire';
$lang['customers_import_customers_from_excel'] = 'Importer Les clients à partir d\'Excel';
$lang['customers_duplicate_account_id'] = 'Votre importation a échoué en raison de dupliquer id du client ou des données invalides, s\'il vous plaît vérifier votre fichier .CVS et essayez à nouveau';
$lang['customers_cleanup_old_customers'] = 'Nettoyage anciens clients';
$lang['customers_cleanup_sucessful'] = 'Les clients on été nettoyé avec succès';
$lang['customers_confirm_cleanup'] = 'Etes-vous sûr de vouloir nettoyer tous les clients supprimés? (Cela va supprimer les numéros de compte des clients supprimés afin qu\'ils puissent être réutilisés)';
?>