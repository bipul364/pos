<?php
$lang['item_kits_name'] = 'Nom de la trousse';
$lang['item_kits_description'] = 'Description de la trousse';
$lang['item_kits_no_item_kits_to_display'] = 'Aucun trousse a afficher';
$lang['item_kits_update'] = 'mise a jour de la trousse';
$lang['item_kits_new'] = 'Nouvelle trousse';
$lang['item_kits_none_selected'] = "Vous n'avez pas sÈlectionnÈ de trousses d'articles";
$lang['item_kits_info'] = 'information sur la Trousse';
$lang['item_kits_successful_adding'] = 'Vous avez ajoutÈ la trousse avec succËs';
$lang['item_kits_successful_updating'] = 'L\'ajout de la trousse ‡ ÈchouÈ';
$lang['item_kits_error_adding_updating'] = 'Erreur d\'ajout / mise ‡ jour de la trousse';
$lang['item_kits_successful_deleted'] = 'Vous avez suprimÈ la trousse avec succËs';
$lang['item_kits_confirm_delete'] = 'Etes-vous s˚r de vouloir supprimer la trousses sÈlectionnÈ?';
$lang['item_kits_one_or_multiple'] = 'Trousses d\'Article(s)';
$lang['item_kits_cannot_be_deleted'] = 'Impossible de supprimer la trousse(s)';
$lang['item_kits_add_item'] = 'Ajouter l\'Article';
$lang['item_kits_items'] = 'Articles';
$lang['item_kits_item'] = 'Article';
$lang['item_kits_quantity'] = 'Quantiter';
?>