<?php
$lang['error_no_permission_module']='Vous navez pas les permissions requis pour aceder a ce module';
$lang['error_unknown']='inconnue';
?>
