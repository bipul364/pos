<?php
$lang['employees_employee']='Employer';
$lang['employees_new']='Nouvel Employer';
$lang['employees_update']='Actualiser Employer';
$lang['employees_confirm_delete']='Etes vous sure de vouloir supprimer employer selectionné?';
$lang['employees_none_selected']='Aucun employer nest selectionné pour Suppression';
$lang['employees_error_adding_updating'] = 'Erreur en Ajoutant/Actualisant employer';
$lang['employees_successful_adding']='Employer ajouté avec succès';
$lang['employees_successful_updating']='Employer actualisé correctement';
$lang['employees_successful_deleted']='Employer suprimmé correctement';
$lang['employees_one_or_multiple']='employer(s)';
$lang['employees_cannot_be_deleted']='Impossible de Supprimer employer selectionné. un ou plusiseur employer a une vente en cours ou vous tentez de vous Supprimer.';
$lang['employees_username']='utilisateur';
$lang['employees_password']='Identifiant';
$lang['employees_repeat_password']='retaper Identifiant';
$lang['employees_username_required']='Le champ utilisateur est requie';
$lang['employees_username_minlength']='Nom Utilisateur doit etre aumoin 5 caracteres';
$lang['employees_password_required']='Identifiant requeris';
$lang['employees_password_minlength']='Identifiant doit etre aumoin 8 caracteres';
$lang['employees_password_must_match']='Les Identifiants doivent coincider';
$lang['employees_basic_information']='Information Employer';
$lang['employees_login_info']='Information de connexion';
$lang['employees_permission_info']='Permission et Accès Employer';
$lang['employees_permission_desc']='Activer la case pour donner la permission au module';
$lang['employees_error_updating_demo_admin'] = 'Vous ne pouvez changer utilisateur demo admin';
$lang['employees_error_deleting_demo_admin'] = 'Vous ne pouver effacer utilisateur demo admin';
?>