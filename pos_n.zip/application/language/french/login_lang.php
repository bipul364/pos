<?php
$lang['login_login']='Session';
$lang['login_username']='Utilisateur';
$lang['login_password']='Identifiant';
$lang['login_go']='Ir';
$lang['login_invalid_username_and_password']='Utilisateur/Identifiant invalide';
$lang['login_welcome_message']='Bienvenue(a) sur le system PHP Point Of Sale. Pour continuer, ouvrez une session avec votre Utilisateur et Identifiant.';
$lang['login_version'] = 'Version';
$lang['login_confirm_password'] = 'Confirmer le mot de passe';
$lang['login_reset_password_for'] = 'RÈinitialiser le mot de passe pour';
$lang['login_reset_password'] = 'RÈinitialiser le mot de passe';
$lang['login_reset_password_message'] = 'Vous avez demandÈ pour rÈinitialiser votre mot de passe, s\'il vous plaÓt cliquer sur le lien ci-dessous afin de complÈter le processus de rÈinitialisation de mot de passe';
$lang['login_password_reset_has_been_sent'] = 'Une rÈinitialisation de mot de passe e-mail a ÈtÈ envoyÈ ‡ votre adresse e-mail. S\'il vous plaÓt vÈrifier vos e-mail et cliquez sur le lien.';
$lang['login_password_has_been_reset'] = 'Votre mot de passe a ÈtÈ rÈinitialisÈ, s\'il vous plaÓt cliquer sur le lien suivant: ';
$lang['login_passwords_must_match_and_be_at_least_8_characters'] = 'Les mots de passe doivent correspondre et Ítre au moins 8 caractËres';
?>