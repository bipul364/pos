<?php
$lang['receivings_register']='Reception d\'Articles';
$lang['receivings_mode']='Mode de Reception';
$lang['receivings_receiving']='Reception';
$lang['receivings_return']='Retour';
$lang['receivings_total']='Total';
$lang['receivings_cost']='Cout';
$lang['receivings_quantity']='QtÈ.';
$lang['receivings_discount']='Disc %';
$lang['receivings_edit']='Edit';
$lang['receivings_new_supplier'] = 'Nouveau';
$lang['receivings_supplier'] = 'Fournisseur';
$lang['receivings_select_supplier']='Selectionner Fournisseur (Optional)';
$lang['receivings_start_typing_supplier_name']='Taper le nom du Fournisseur...';
$lang['receivings_unable_to_add_item']='Impossible dajouter l\'Article recue';
$lang['receivings_error_editing_item']='Erreur en editant l\'article';
$lang['receivings_receipt']='RÈception des recues';
$lang['receivings_complete_receiving']='terminÈ';
$lang['receivings_confirm_finish_receiving'] = 'es vous sure de vouloir soumettrele le recue? ceci ne peut Ítre annulÈe.';
$lang['receivings_confirm_cancel_receiving'] = 'Etes-vous s˚r de vouloir effacer cette rÈception? Tous les articles seront effacÈ.';
$lang['receivings_find_or_scan_item']='Trouver/Scanner article';
$lang['receivings_find_or_scan_item_or_receipt']='trouver/Scanner article ou Recue';
$lang['receivings_id']='ID de Reception';
$lang['receivings_item_name'] = 'Nom d\'article';
$lang['receivings_transaction_failed'] = 'Reception de Transactions echouÈ';
$lang['receivings_delete_successful'] = 'la rÈception a ÈtÈ SupprimÈ avec succËs';

$lang['receivings_delete_unsuccessful'] = 'La supression de la reception a ÈchouÈ';

$lang['receivings_edit_receiving'] = 'Modifier la RÈception';
$lang['receivings_supplier'] = 'fournisseur';

$lang['receivings_delete_entire_receiving'] = 'Supprimer Toutes les RÈceptions';

$lang['receivings_successfully_updated'] = 'La Reception a ÈtÈ mises ‡ jour avec succËs';

$lang['receivings_unsuccessfully_updated'] = 'La mise a jour de la reception ‡ ÈchouÈ';
$lang['receivings_undelete_entire_sale'] = 'Restaurer toutes Receptions';
$lang['receivings_undelete_confirmation'] = 'Etes-vous s˚r de vouloir restaurer cette rÈception?';

$lang['receivings_undelete_successful'] = 'la rÈception a ÈtÈ restaurÈ avec succËs';


$lang['receivings_delete_unsuccessful'] = 'La supression de la reception a ÈchouÈ';
$lang['receivings_cancel_receiving'] = 'Annuler Reception.';
?>