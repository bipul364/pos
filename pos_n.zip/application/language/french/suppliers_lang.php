<?php
$lang['suppliers_new']='Nouveau';
$lang['suppliers_supplier']='Fournisseur';
$lang['suppliers_update']='Actualiser Fournisseur';
$lang['suppliers_confirm_delete']='êtes vous sure de vouloir supprimer le Fournisseur selectionné?';
$lang['suppliers_none_selected']='vous navez selectionné aucun Fournisseur pour Suppression';
$lang['suppliers_error_adding_updating'] = 'Erreur ajoutant/actualisant Fournisseur';
$lang['suppliers_successful_adding']='vous avez ajouté le Fournisseur correctement';
$lang['suppliers_successful_updating']='vous avez actualisé le Fournisseur correctement';
$lang['suppliers_successful_deleted']='vous avez supprimé le Fournisseur correctement';
$lang['suppliers_one_or_multiple']='Fournisseur(s)';
$lang['suppliers_cannot_be_deleted']='Impossible de Supprimer le Fournisseur selectioné. Un ou plusieur fournisseur seleccioné a une vente en cour.';
$lang['suppliers_basic_information']='Information du Fournisseur';
$lang['suppliers_account_number']='Compte #';
$lang['suppliers_company_name']='Nom de compagnie';
$lang['suppliers_company_name_required'] = 'Le champ nom de Compagnie est requis';
?>