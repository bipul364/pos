<?php $this->load->view("partial/header"); ?>
<table id="title_bar">
	<tr>
		<td id="title_icon"> </td>
		<td id="title">
			<?php echo  ('Sale Reports Details For All');
   
			?>
	 
		</td>
	</tr>
</table>

 
<div id="config_wrapper">



	<fieldset id="config_info">
		<legend><?php echo "Details Sale Report"; ?></legend>

		<table  border="1" class="tablesorter report">
  <tbody>
    <tr>
      <td class="innertable" colspan="5"><table class="innertable">
        <thead>
          <tr style="background: #5582B0; height:30px">
            <th   align="left">SN</th>
            <th align="left">Customer Name</th>
            <th align="left">Total Amount </th>
               <th align="left">Payment Amount</th>
            <th align="left">Due Amount </th>
      

          </tr>
        </thead>
        <tbody>
         <style  type="text/css">
    .even {
    background-color:#DBEAF9;
}
td
{
text-align:center;
}
    </style>
         <?php 
         $this->load->model('salereportsfroallmodel');
$SN=0;
$due=0;
$recipt=0;
$Total_amount=0;
 $datefrom;
 $dateto;
          foreach ($salesdata  as $row)
 {
 	$SN++;
 	?>
          <tr height="35" border="1"  <?php echo $SN % 2 ? 'class="even"' : ''; ?> >
            <td align="left"><?php echo $SN; ?></td>
            <td align="left"><?php echo $row->first_name.' '.$row->last_name ;?></td>
             <td align="left"><?php  $toalamount= $this->salereportsfroallmodel->totalsale($row->person_id);
             echo number_format($toalamount,2,'.','');
              ?></td>
              <td align="left"><?php    $toalpay=$this->salereportsfroallmodel->totalpay($row->person_id);
              echo  number_format($toalpay,2,'.','')
              ?></td>
                <td align="left"><?php echo $totaldue= number_format($toalamount-$toalpay,2,'.','');?></td>
                </tr>
          
          
           <?php  
           $Total_amount=$Total_amount+$toalamount;
           $recipt=$recipt+$toalpay;
           $due=$due+$totaldue;
 }
           ?>
             <tr style="background: #5582B0; height:35px;font-size:13px; font-weight:bold; ">

            <td align="left"></td>
            <td align="Center">Total :</td>
            <td align="left"><?php echo number_format($Total_amount,2); ?> </td>
            <td align="left"><?php echo number_format($recipt,2); ?> </td>
          <td align="left"><?php echo number_format($due,2); ?> </td>
            
            </tr>
        </tbody>
      </table></td>
    </tr>
  </tbody>
</table>
		 

		 

		 
 
</fieldset>
</div>
 
<div id="feedback_bar" style="top: 1150px;"></div>
 
<?php $this->load->view("partial/footer"); ?>


