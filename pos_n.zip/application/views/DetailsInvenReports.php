<?php $this->load->view("partial/header"); ?>
<table id="title_bar">
	<tr>
		<td id="title_icon"> </td>
		<td id="title">
			<?php echo  ('Item Reports Details For');
   
			?>
			<?php   $customer=$this->Item->get_info($item);
			echo $customer->name;?>
		</td>
	</tr>
</table>

 
<div id="config_wrapper">



	<fieldset id="config_info">
		<legend><?php echo "Item Sale Report"; ?></legend>

		<table  class="tablesorter report">
  <tbody>
    <tr>
      <td class="innertable" colspan="6"><table class="innertable">
        <thead>
          <tr style="background: #5582B0; height:30px">
            <th   align="left">SN</th>
            <th align="left">Date</th>
            <th align="center">Item Name </th>
               <th align="right">Type</th>
            <th align="right">Sale/ Entry</th>
            <th align="center">Balance Now </th>
             

          </tr>
        </thead>
        <tbody>
         <style  type="text/css">
    .even {
    background-color:#DBEAF9;
}
td
{
text-align:center;}
    </style>
         <?php 
        // $this->load->model('SaleReportsModel');
$SN=0;
$due=0;
$recipt=0;
$Total_amount=0;
          foreach ($salesdata  as $row)
 {
 	$SN++;
 	?>
          <tr height="30"  <?php echo $SN % 2 ? 'class="even"' : ''; ?>  > 
            <td align="left"><?php echo $SN; ?></td>
            <td align="left"><?php echo date('d/M/Y',strtotime($row->trans_date));?></td>
             <td align="left"><?php echo $row->name; ?></td>
        
                 <td align="right"><?php 
               if($row->trans_inventory>0) 
               	echo "Entry";
               else echo  "Sales";
               	?></td>
            <td align="right"><?php   
            	$recipt=$recipt+$row->trans_inventory;
            	echo  $row->trans_inventory;
            ?></td>
             <td align="center"><?php echo $recipt; ?></td>
    
        
          </tr>
          
          
           <?php  
 }
           ?>
             <tr style="background: #5582B0; height:35px;font-size:13px; font-weight:bold; ">
            <td align="left"></td>
            <td align="left"></td>
       
            <td align="Center"></td>
            <td align="right"> Total :</td>
            <td align="right">  </td>
            <td align="center"><?php echo $recipt;  ?> </td>
            
            </tr>
        </tbody>
      </table></td>
    </tr>
  </tbody>
</table>
		 

		 

		 
 
</fieldset>
</div>
 
<div id="feedback_bar" style="top: 1150px;"></div>
 
<?php $this->load->view("partial/footer"); ?>


