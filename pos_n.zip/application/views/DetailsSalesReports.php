<?php $this->load->view("partial/header"); ?>
<table id="title_bar">
	<tr>
		<td id="title_icon"> </td>
		<td id="title">
			<?php echo  ('Sale Reports Details For');
   
			?>
			<?php  $customer=$this->SaleReportsModel->get_info($customer_id);
			echo $customer->first_name.' '.$customer->last_name;?>
		</td>
	</tr>
</table>

 
<div id="config_wrapper">



	<fieldset id="config_info">
		<legend><?php echo "Details Sale Report"; ?></legend>

		<table  class="tablesorter report">
  <tbody>
    <tr>
      <td class="innertable" colspan="6"><table class="innertable">
        <thead>
          <tr style="background: #5582B0; height:30px">
            <th   align="left">SN</th>
            <th align="left">Date</th>
            <th align="center">Invoice No </th>
               <th align="right">Payment Type</th>
            <th align="right">Total Amount </th>
            <th align="right">Payment</th>
            <th align="right">Due</th>

          </tr>
        </thead>
        <tbody>
            <style  type="text/css">
    .even {
    background-color:#DBEAF9;
}
td
{
text-align:center;}
    </style>
         <?php 
         $this->load->model('SaleReportsModel');
$SN=0;
$due=0;
$recipt=0;
$Total_amount=0;
          foreach ($salesdata  as $row)
 {
 	$SN++;
 	?>
          <tr height="35" <?php  echo $i++ % 2 ? 'class="even"' : ''; ?> >
            <td align="left"><?php echo $SN; ?></td>
            <td align="left"><?php echo date('d/M/Y',strtotime($row->sale_time));?></td>
             <td align="left"><?php echo $row->sale_id; ?></td>
       
            <td align="center"><?php echo $row->payment_type; ?></td>
                 <td align="right"><?php 
               if($row->sale_id!=$reid){
                 $total= $this->SaleReportsModel->cost_price($row->sale_id); 
                 echo number_format($total,2); 
                 $Total_amount=$Total_amount+$total;
                 $reid=$row->sale_id;
}?></td>
            <td align="right"><?php  if($row->payment_type!='Due'){
            	$recipt=$recipt+$row->payment_amount;
            	echo number_format($row->payment_amount,2);
            } ?></td>
             <td align="right"><?php  if($row->payment_type=='Due')  {
             	$due=$due+$row->payment_amount;
             	echo number_format($row->payment_amount,2); }?></td>
    
        
          </tr>
          
          
           <?php  
 }
           ?>
             <tr style="background: #5582B0; height:35px;font-size:13px; font-weight:bold; ">
            <td align="left"></td>
            <td align="left"></td>
            <td align="left"></td>
            <td align="Center">Total :</td>
            <td align="right"><?php echo number_format($Total_amount,2); ?> </td>
            <td align="right"><?php echo number_format($recipt,2); ?> </td>
          <td align="right"><?php echo number_format($Total_amount-$recipt,2); ?> </td>
            
            </tr>
        </tbody>
      </table></td>
    </tr>
  </tbody>
</table>
		 

		 

		 
 
</fieldset>
</div>
 
<div id="feedback_bar" style="top: 1150px;"></div>
 
<?php $this->load->view("partial/footer"); ?>


