<!DOCTYPE html>
<html>
<head>
	<title><?php echo lang('login_reset_password'); ?></title>
</head>
<body>
<?php echo lang('login_password_reset_has_been_sent'); ?>
</body>
</html>