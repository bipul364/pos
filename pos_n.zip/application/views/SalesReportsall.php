<?php $this->load->view("partial/header"); ?>
<table id="title_bar">
	<tr>
		<td id="title_icon"> </td>
		<td id="title">
			<?php echo  ('Sale Reports For All Customer'); ?>
		</td>
	</tr>
</table>
<?php
	echo form_open_multipart('DetailsReports/specific_sale',array('id'=>'specific_sale'));
	$format="Y-m-d";
	$date=date('Y-m-d');
?>
<div id="config_wrapper">
	<fieldset id="config_info">
		<legend><?php echo lang("SalesReports_info"); ?></legend>

		<ul id="error_message_box"></ul>

		<div class="field_row clearfix">	
<?php echo form_label('Select Date from :','datefrom',array('class'=>'wide')); ?>
	<div class='form_field'>
	<?php echo form_input(array(
		'name'=>'datefrom',
		'id'=>'datefrom',
		'value'=> date ( $format, strtotime ( '-1 month' . $date ) )));?>
		  
		 Select Date To 
		  <?php echo form_input(array(
		'name'=>'dateto',
		'id'=>'dateto',
		'value'=> date ( $format, strtotime ( '1 day' . $date ) )));?>
	</div>
		</div>

<?php 
echo form_submit(array(
	'name'=>'submitf',
	'id'=>'submitf',
	'value'=>lang('common_submit'),
	'class'=>'submit_button float_right')
);
?>
</fieldset>
</div>
<?php
echo form_close();
?>
<div id="feedback_bar" style="top: 1150px;"></div>
<script type='text/javascript'>

//validation and submit handling
$(document).ready(function()
{
	$("#dbOptimize .dbOptimize").click(function(event)
	{
		event.preventDefault();
		$("#optimize_loading").show();
		
		$.getJSON($(this).attr('href'), function(response) 
		{
			alert(response.message);
			$("#optimize_loading").hide();
		});
		
	});
	var submitting = false;
	$('#config_form').validate({
		submitHandler:function(form)
		{
			if (submitting) return;
			submitting = true;
			$(form).ajaxSubmit({
			success:function(response)
			{
				if(response.success)
				{
					set_feedback(response.message,'success_message',false);		
				}
				else
				{
					set_feedback(response.message,'error_message',true);		
				}
				submitting = false;
			},
			dataType:'json'
		});

		},
		errorLabelContainer: "#error_message_box",
 		wrapper: "li",
		rules: 
		{
			company: "required",
			address: "required",
    		phone: "required",
    		email:"email",
    		return_policy: "required"    		
   		},
		messages: 
		{
     		company: <?php echo json_encode(lang('config_company_required')); ?>,
     		address: <?php echo json_encode(lang('config_address_required')); ?>,
     		phone: <?php echo json_encode(lang('config_phone_required')); ?>,
     		email: <?php echo json_encode(lang('common_email_invalid_format')); ?>,
     		return_policy:<?php echo json_encode(lang('config_return_policy_required')); ?>
	
		}
	});
});
</script>
<?php $this->load->view("partial/footer"); ?>


