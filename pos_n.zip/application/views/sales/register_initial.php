<?php $this->load->view("partial/header"); ?>
<div id="register_container" class="sales">
	<?php $this->load->view("sales/register"); ?>
</div>
<?php $this->load->view("partial/footer"); ?>
